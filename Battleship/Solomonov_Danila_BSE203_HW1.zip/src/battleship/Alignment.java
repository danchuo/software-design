package battleship;

public enum Alignment {
    VERTICAL,
    HORIZONTAL
}
