package battleship;

@FunctionalInterface
public interface CreateShipInterface {
  Ship createShip();
}
