package battleship;

public enum ResultOfHit {
  MISS,
  HIT,
  HIT_AND_SUNK,
  ALREADY_HIT,
  ALREADY_SUNK,
}
