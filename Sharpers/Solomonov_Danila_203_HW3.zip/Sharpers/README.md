To start the game, you need to pass the necessary command line parameters in this format: 
[players] [sharpers], where [players] can be in the range [1;100] and [sharpers] can be in the range [0;100].
For example, this command can easily run the program:
>java -jar main.jar 1 2
 
If any of the parameters is incorrect, the program will prompt you to enter it into the console yourself.
