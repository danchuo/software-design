package com.danchuo.jigsawclient;

public record Point(int x, int y) {
}
