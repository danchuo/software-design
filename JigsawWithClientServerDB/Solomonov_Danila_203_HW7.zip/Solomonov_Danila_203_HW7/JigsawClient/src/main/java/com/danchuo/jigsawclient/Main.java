package com.danchuo.jigsawclient;

public final class Main {
  private Main() {}

  public static void main(String... args) {
    JigsawApplication.main(args);
  }
}
