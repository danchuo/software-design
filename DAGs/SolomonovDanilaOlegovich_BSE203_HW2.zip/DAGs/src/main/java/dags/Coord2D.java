package dags;

public record Coord2D(double x, double y) {

}
